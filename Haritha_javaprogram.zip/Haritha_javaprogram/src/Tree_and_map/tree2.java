package Tree_and_map;

import java.util.TreeSet;

public class tree2 {

	public static void main(String[] args) {
		  TreeSet<String> ts = new TreeSet<>();
		     
	      // Add elements to the tree set
	      System.out.println(ts.add("A"));
	      System.out.println(ts.add("A"));
//	      
	      System.out.println(ts);
	   }
		// TODO Auto-generated method stub

	}


