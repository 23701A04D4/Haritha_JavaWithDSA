package Tree_and_map;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class hash5 {

	public static void main(String[] args) {
		  
        Integer[] A = {22, 45,33, 66, 55, 34, 77};  
        Integer[] B = {33, 2, 83, 45, 3, 12, 55};  
        
   
        
        Set<Integer> set1 = new HashSet<Integer>();    
        set1.addAll(Arrays.asList(A));
        set1.add(78);
        System.out.println(set1);
        
        Set<Integer> set2 = new HashSet<Integer>();    
        set2.addAll(Arrays.asList(B));
        System.out.println(set2);
    
      
    
        // Finding Intersection of set1 and set2    
        Set<Integer> intersection_data = new HashSet<Integer>(set1);    
        intersection_data.retainAll(set2);    
        System.out.print("Intersection of set1 and set2 is:");    
        System.out.println(intersection_data);    
    
         }    

// TODO Auto-generated method stub

	}


