package Tree_and_map;

import java.util.HashMap;
import java.util.Map;

public class map {

	public static void main(String[] args) {
		
		        
		        // Creating a HashMap
		        Map<String, Integer> map = new HashMap<>();

		        // Adding key-value pairs
		        map.put("Apple", 3);
		        map.put("Banana", 5);
		        map.put("Orange", 2);

		        // Getting a value
		        System.out.println("Apple count: " + map.get("Apple"));

		        // Iterating through entries
		        for (Map.Entry<String, Integer> entry : map.entrySet()) {
		            System.out.println(entry.getKey() + " => " + entry.getValue());
		        }

		        // Checking if a key exists
		        if (map.containsKey("Banana")) {
		            System.out.println("Banana exists");
		        }

		        // Removing a key
		        map.remove("Orange");

		        // Checking size after removal
		        System.out.println("Size: " + map.size());
		    }
			// TODO Auto-generated method stub

	}


