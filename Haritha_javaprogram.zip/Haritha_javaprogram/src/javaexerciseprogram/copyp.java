package javaexerciseprogram;

public class copyp {

	public static void main(String[] args) {
		String s1="virat";
		String s2="";
		s2=s1;
		System.out.println(s2);
	String s3="kohli";
	s2+=s3;
	System.out.println(s2);
		// TODO Auto-generated method stub

	}

}
