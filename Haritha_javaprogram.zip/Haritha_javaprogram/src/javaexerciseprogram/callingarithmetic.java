package javaexerciseprogram;

import javapraticeprogram.arithmeticoperation1;

public class callingarithmetic {

	public static void main(String[] args) {
		
		arithmeticoperation1 obj=new arithmeticoperation1();// TODO Auto-generated method stub
		System.out.println(obj.sum(6, 6));
	}

}
