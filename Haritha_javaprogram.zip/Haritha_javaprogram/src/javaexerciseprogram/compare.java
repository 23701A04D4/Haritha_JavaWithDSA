package javaexerciseprogram;

public class compare {

	public static void main(String[] args) {
		String s1="nani";
		String s2="mani";
		String s3="hari";
		String s4="suni";
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareTo(s3));
		System.out.println(s1.compareTo(s4));
		System.out.println(s2.compareTo(s1));
		System.out.println(s2.compareTo(s3));
		System.out.println(s2.compareTo(s4));
		System.out.println(s3.compareTo(s1));
		System.out.println(s3.compareTo(s2));
		System.out.println(s3.compareTo(s4));
		System.out.println(s4.compareTo(s1));
		System.out.println(s4.compareTo(s2));
		System.out.println(s1.compareTo(s3));// TODO Auto-generated method stub

	}

}
