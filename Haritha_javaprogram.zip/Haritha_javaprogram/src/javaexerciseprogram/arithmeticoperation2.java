package javaexerciseprogram;

public class arithmeticoperation2 {
	
	public double sum(double a,double b)
	{
		double c=a+b;
		return c;

}
}