package Stack_and_Queue;

public class Queue {
	private int[] queue;
	private int front,rear,size,capacity;
	
	public Queue(int capacity) {
		this.capacity=capacity;
		queue=new int[capacity];
		front=0;
		rear=-1;
		size=0;
	}
	
	public void enqueue(int value) {
		if(isfull()) {
			System.out.println("queue is full!");
			return;
		}
		rear=(rear+1)%capacity;
		queue[rear]=value;
		size++;
		System.out.println("Enqueued:" +value);
	}
	public int dequeue() {
		if (isempty()) {
			System.out.println("Queue is empty!");
			return -1;
		}
		int removed=queue[front];
		front=(front+1)%capacity;
		size--;
		return removed;
	}
public int peak() {
	if(isempty()) {
		System.out.println("queue is empty!");
		return -1;
	}
	return queue[front];
}
public boolean isempty() {
	return size==0;
}
public boolean isfull() {
	return size==capacity;
}
public void display() {
	System.out.print("queue:");
	for (int i=0;i<size;i++) {
		int index =(front +i)%capacity;
		System.out.print(queue[index]+"");
	}
	System.out.println();
}
	public static void main(String[] args) {
		Queue q=new Queue(5);
		q.enqueue(10);
		q.enqueue(20);
		q.enqueue(30);
		q.display();
		System.out.println("dequeued:" +q.dequeue());
		q.display();
		System.out.println("front element:" +q.peak());// TODO Auto-generated method stub

	}

}
