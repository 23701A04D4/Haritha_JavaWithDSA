package javapraticeprogram;

public class arrayaddition {

	public static void main(String[] args) {

		int y []={1,2,3,4,5,6,7};
		 int sum=-35;
		for (int i = 0; i< y.length; i++) {  
	           sum = sum + y[i];  
	        }  
	        System.out.println("Sum of all the elements of an array: " + sum);  
	    }  
	// TODO Auto-generated method stub

	}

