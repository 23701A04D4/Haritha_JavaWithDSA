package javapraticeprogram;

public class typecasting {

	public static void main(String[] args) {
		double i=10.0;
	      int x=(int)i;
		
		System.out.println(x);
	}

}
