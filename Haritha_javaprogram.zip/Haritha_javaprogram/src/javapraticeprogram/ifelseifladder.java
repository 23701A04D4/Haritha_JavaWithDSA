package javapraticeprogram;

public class ifelseifladder {

	public static void main(String[] args) {
		 int height=0;
		 if (height>=5) {
System.out.println("tall");
			 }
			 else if(height>=4) {
System.out.println("medium");
		 }
		else if(height>=3) {
System.out.println("short");
		}
		else
System.out.println("no height");
         }
		
	}






