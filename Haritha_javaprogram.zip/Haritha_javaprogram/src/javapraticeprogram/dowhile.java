package javapraticeprogram;

public class dowhile {

	public static void main(String[] args) {
	int k=0;
		do
		{
System.out.println("hello welcome");
        k=k+1;
		}
		while(k<=4);
		
		
	// TODO Auto-generated method stub

	}

}
