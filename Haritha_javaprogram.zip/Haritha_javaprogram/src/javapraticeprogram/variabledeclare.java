package javapraticeprogram;

public class variabledeclare {

	public static void main(String[] args) {
		int a,b,c;
		System.out.println("a");// TODO Auto-generated method stub

	}

}
