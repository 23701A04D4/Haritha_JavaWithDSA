package javapraticeprogram;

import javaexerciseprogram.arithmeticoperation2;

public class callingarithmetic1 {

	public static void main(String[] args) {
		arithmeticoperation2 obj=new arithmeticoperation2();
		System.out.print(obj.sum(14.8,23.7));
    // TODO Auto-generated method stub

	}

}
