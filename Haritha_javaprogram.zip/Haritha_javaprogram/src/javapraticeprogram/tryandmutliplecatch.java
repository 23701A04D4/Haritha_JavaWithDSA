package javapraticeprogram;

public class tryandmutliplecatch {

	public static void main(String[] args) {
		try{    
        	double a[] = new double [9];    // 0 1 2 3 4 
        	a[9] = 93.5;    			// 6
       }    
       catch(ArithmeticException e)  
       {  
    	   System.out.println("Arithmetic Exception occurs");  
       }    
       catch(ArrayIndexOutOfBoundsException e)  
       {  
           System.out.println("memory is full");  
       }    
       catch(Exception e)  
       {  
           System.out.println(e);  
       }             
       System.out.println("Executed seccesfully");   
	}
// TODO Auto-generated method stub

	}


