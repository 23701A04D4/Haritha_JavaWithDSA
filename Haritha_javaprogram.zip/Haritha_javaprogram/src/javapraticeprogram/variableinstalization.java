package javapraticeprogram;

public class variableinstalization {

	public static void main(String[] args) {
		int x,t,y;
		x=10;t=95;y=20;
		System.out.println(x+t+y);// TODO Auto-generated method stub

	}

}
