package javapraticeprogram;

public class mainfunction {

	public static void main(String[] args) {
	FoodS obj =new FoodS();	// TODO Auto-generated method stub
obj.print();
obj.print1();

	}

}
