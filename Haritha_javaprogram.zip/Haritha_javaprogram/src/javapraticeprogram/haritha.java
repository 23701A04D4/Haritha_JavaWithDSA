package javapraticeprogram;

public class haritha {
	void method()throws Exception 
	{
	int a=50/0;
	System.out.println(a);
	}
}
class rama{
	public static void main(String[] args) {
		try{
			haritha obj=new haritha();
			obj.method();
			// TODO Auto-generated method stub
		}
catch(Exception e) {
	System.out.println("Exception handled");
}
		System.out.println("inside main function");
	}

}
