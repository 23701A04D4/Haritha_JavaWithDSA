package javapraticeprogram;

interface Nonveg {
	void print1();

}
