package javapraticeprogram;

public class printstatement {

	public static void main(String[] args) {
		System.out.println("hi welcome");// TODO Auto-generated method stub

	}

}
