package javapraticeprogram;

public class currenrrate {

	public static void main(String[] args) {
		int unit=150;
		int rate=5;
		if (unit>=150){
			rate=5;
		if(unit>=250) {
			rate=3;
			if(unit>=350){
				rate=2;// TODO Auto-generated method stub
			}
		}
		}
		else {
			System.out.println("no current bill");
		}
		System.out.println(unit*rate);
	}
	

}
