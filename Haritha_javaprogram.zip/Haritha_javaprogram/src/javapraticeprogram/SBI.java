package javapraticeprogram;

public class SBI extends RBI {
	float getRateOfInterest()
	{
		return 6.8f;
	}

}
