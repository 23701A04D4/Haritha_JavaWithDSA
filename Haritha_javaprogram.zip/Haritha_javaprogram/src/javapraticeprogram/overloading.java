package javapraticeprogram;

public class overloading {
	int s,i,r;
	void sum(int s,int i) {
		this.s=s;
		this.i=i;
		r=s+i;
		print();
	}
void print() {
	System.out.println(r);
}
void sum(int s,int i,int r) {
	System.out.println(s+i+r);
}
	public static void main(String[] args) {
		overloading obj=new overloading();
		obj.sum(30,30);
		obj.sum(30,30,20);// TODO Auto-generated method stub

	}

}
