package javapraticeprogram;

public class FoodS implements Veg,Nonveg{
	
	public void print()
	{
System.out.println("our food is ready ");
}
    public void print1()
    {
System.out.println("lets go and enjoy");
    }
}
