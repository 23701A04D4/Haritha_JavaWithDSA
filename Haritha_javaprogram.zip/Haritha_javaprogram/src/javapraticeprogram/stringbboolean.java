package javapraticeprogram;

public class stringbboolean {

	public static void main(String[] args) {
		String h="bharath";
		System.out.println(h.startsWith("BH"));
		System.out.println(h.endsWith("h"));// TODO Auto-generated method stub

	}

}
