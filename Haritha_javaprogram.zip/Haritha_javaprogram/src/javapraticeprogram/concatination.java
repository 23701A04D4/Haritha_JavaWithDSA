package javapraticeprogram;

public class concatination {

	public static void main(String[] args) {
		String s1="haritha is ";
		s1=s1.concat("very good girl");
		System.out.println(s1);
		s1=s1.concat(" and strong");
		System.out.println(s1);
		
		// TODO Auto-generated method stub

	}

}
