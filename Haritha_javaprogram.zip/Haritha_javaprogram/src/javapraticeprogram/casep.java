package javapraticeprogram;

public class casep {

	public static void main(String[] args) {
		String a="haritha";
		System.out.println(a.toUpperCase());//SACHIN    
		System.out.println(a.toLowerCase());//sachin    
		System.out.println(a);
		// TODO Auto-generated method stub

	}

}
