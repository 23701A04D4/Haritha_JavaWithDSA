package javapraticeprogram;

public class operators {

	public static void main(String[] args) {
		int a,b;
		a=1;b=0;
System.out.println(a|b);
System.out.println(a&b);
System.out.println(a<b);
System.out.println(a>b);
System.out.println(a!=b);
System.out.println(a+=b);
System.out.println(a-=b);

		// TODO Auto-generated method stub

	}

}
