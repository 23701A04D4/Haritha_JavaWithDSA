package javapraticeprogram;

public class personalinformation {

	public static void main(String[] args) {
		System.out.println("Name=L.Naga Haritha");
		System.out.println("age=19");
		System.out.println("Phone number=9398351239");
		System.out.println("Email id=lharithareedy13@gmail.com");
		
		// TODO Auto-generated method stub

	}

}
