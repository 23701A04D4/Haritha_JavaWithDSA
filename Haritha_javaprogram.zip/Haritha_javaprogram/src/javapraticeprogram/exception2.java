package javapraticeprogram;

import java.util.Scanner;

public class exception2 {
	 static void validate(int employeeAge)
	   {  
	     if(employeeAge <= 20)  						
	      throw new ArithmeticException("Not valid");  
	     else  
	      System.out.println("Welcome to CTS");  
	      
	   }  
	   
	   public static void main(String args[]){  
		   Scanner sc = new Scanner(System.in);
		   System.out.println("Enter your age : ");
		   int employeeAge = sc.nextInt();
		   try {
			   validate(employeeAge);
		   }
		   catch(Exception e)
		   { System.out.println(e);	}
		   
	      System.out.println("Execution over");  
	  }  
	

		// TODO Auto-generated method stub

	}

