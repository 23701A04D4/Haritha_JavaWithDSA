package javapraticeprogram;

public class lengthofstring {

	public static void main(String[] args) {
		String s="naga HARITHA lakkireddy";// TODO Auto-generated method stub
System.out.println(s.length());
	}

}
