package javapraticeprogram;

public class encapsulation1 {

	private String name;	
	
	public String getName()  
	{
	      return name;
	}
	
	public void setName(String newName)	
	 {						
		    name = newName;   
	 }
}


