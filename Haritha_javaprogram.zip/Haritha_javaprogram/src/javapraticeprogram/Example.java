package javapraticeprogram;

public class Example {

	public static void main(String[] args) {
		RBI obj;
		obj=new SBI();
System.out.println("SBI Rate Of Interest:" +obj.getRateOfInterest());
        obj=new ICICI();
System.out.println("ICICI Rate Of Interest:" +obj.getRateOfInterest());
        obj=new HDFC();
System.out.println("HDFC Rate Of Interest:" +obj.getRateOfInterest());
		// TODO Auto-generated method stub

	}

}
