package javapraticeprogram;

public class arthematicopertars {

	public static void main(String[] args) {
		int a,b;
		a=10;b=5;
System.out.println(a+b);
System.out.println(a-b);
System.out.println(a*b);
System.out.println(a/b);
System.out.println(a%b);

		
		
	}
}	