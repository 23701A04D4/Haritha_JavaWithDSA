package javapraticeprogram;

public class ifelse {

	public static void main(String[] args) {
		int marks=89;
		if(marks>=90){
System.out.println("s grade");
		}// TODO Auto-generated method stub
else
System.out.println("grade a");
	}

}
