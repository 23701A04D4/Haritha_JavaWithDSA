package javapraticeprogram;



public class encapsulation2 {

	public static void main(String[] args) 
	{
		encapsulation1 obj = new encapsulation1();
	    
		obj.setName("Vivek");
	    System.out.print("Name : " + obj.getName());  //vivek
	}

}


