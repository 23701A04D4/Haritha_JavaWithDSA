package javapraticeprogram;

public class RBI {
float getRateOfInterest()
{
 return 0;
		// TODO Auto-generated method stub

	}

}
