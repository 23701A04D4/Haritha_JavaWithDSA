package javapraticeprogram;


class parents{
	void run() {
		System.out.println("parent method");
	}
}

class overridding  extends parents{
	void run() {
		System.out.println("child method");
	}
	public static void main(String[] args) {
		overridding obj = new overridding();	
		  obj.run();  
		parents obj1 = new parents();
		obj1.run();// TODO Auto-generated method stub

	}

}
