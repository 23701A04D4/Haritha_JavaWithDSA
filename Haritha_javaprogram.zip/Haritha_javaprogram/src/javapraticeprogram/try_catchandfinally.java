package javapraticeprogram;

public class try_catchandfinally {

	public static void main(String[] args) {
		String value ="haritha"; // null;
		 try{  
			   	   System.out.println(value.length());  // 9
			 }  
		 catch(NullPointerException e)    //Exception
		 {
			 System.out.println(e);
		 }  
		 finally
		 {
			  System.out.println("no errors");  // obj.close();
		 }
		 
			  System.out.println("Successfully Finished");  
		 }  
	
// TODO Auto-generated method stub

	}


