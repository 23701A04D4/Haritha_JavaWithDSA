package javapraticeprogram;

public class dataconversion {

	public static void main(String[] args) {
		int a=10;
		double u=30.9;
		int y=(int)u ;
		System.out.println( "int " +y);
		
		// TODO Auto-generated method stub

	}

}
