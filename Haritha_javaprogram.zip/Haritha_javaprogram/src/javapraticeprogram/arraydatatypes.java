package javapraticeprogram;

public class arraydatatypes {

	public static void main(String[] args) {
		float a[]=new float[2];
		a[0]=1.2f;
		a[1]=2.3f;
		System.out.println(a[1]);
		
		// Double
		double b[]=new double[2];
		b[0]=157.4562;
		b[1]=20987.12343;
		System.out.println(b[1]);
		
		// long
		long c[]=new long[3];
		c[0] = 1234567890;
		c[1] = 765437543;
		System.out.println(c[1]);
		
		// String
		String d[]=new String[5];
		d[0]="SIVA ";
		d[1]="GOOD MORNING HARITHA";
		System.out.println(d[1]);	}


// TODO Auto-generated method stub

	}


