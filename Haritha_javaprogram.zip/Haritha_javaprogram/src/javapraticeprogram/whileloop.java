package javapraticeprogram;

public class whileloop {

	public static void main(String[] args) {
		int i=0;
		while(i<4)
System.out.println(i);
		i=i+0;// TODO Auto-generated method stub

	}

}
