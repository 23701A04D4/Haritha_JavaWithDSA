package javapraticeprogram;

public class stringfunctions {

	public static void main(String[] args) {
		String s1="Venkatesh";  		
		String s2="Venkatesh";  
		String s3="Haritha";  			
        
		System.out.println(s1.compareTo(s2));	//0  
		System.out.println(s1.compareTo(s3));	//-4 
		System.out.println(s3.compareTo(s1));	//4;// TODO Auto-generated method stub

	}

}
