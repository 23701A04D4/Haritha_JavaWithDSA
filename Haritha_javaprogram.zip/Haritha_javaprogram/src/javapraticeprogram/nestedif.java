package javapraticeprogram;

public class nestedif {

	public static void main(String[] args) {
		 int percentage=74;
		 int income=250000;
		 if (percentage>=85) {
			 if(income<=200000) {
System.out.println("full scholarship");
			 }
			 else
System.out.println("half scholarship");
		 }
		else
System.out.println("not eligible for scholarship");
// TODO Auto-generated method stub
			 }

	}


