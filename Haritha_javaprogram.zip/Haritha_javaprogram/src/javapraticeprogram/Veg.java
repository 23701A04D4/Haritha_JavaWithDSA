package javapraticeprogram;

interface Veg {
    void print();
    
    
}
