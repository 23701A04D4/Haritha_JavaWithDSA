package javapraticeprogram;

public class ifcondition {

	public static void main(String[] args) {
		int height=6;
				 
     if (height > 5.9) {
		System.out.println("tall");
     }
		
		// TODO Auto-generated method stub

	}

}
