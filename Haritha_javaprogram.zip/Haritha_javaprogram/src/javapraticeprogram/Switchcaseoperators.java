package javapraticeprogram;

import java.util.Scanner;

public class Switchcaseoperators {

	public static void main(String[] args) {
		int a,b,c;
		 a=100; b=200;
		Scanner h=new Scanner(System.in);
		System.out.println("enter a case");
		int q=h.nextInt();
		switch(q) {
		case 1:
		System.out.println("a+b:" +(a+b));
		break;
		case 2:
		System.out.println("a-b:"+(a-b));
		break;
		case 3:
		System.out.println("a*b:"+(a*b));
		break;
		default:
		System.out.println("invaild");
		// TODO Auto-generated method stub

	}

	}
}