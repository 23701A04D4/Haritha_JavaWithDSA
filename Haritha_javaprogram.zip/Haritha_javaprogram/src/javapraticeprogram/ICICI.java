package javapraticeprogram;

public class ICICI extends RBI {
	float getRateOfInterest()
	{
    return 5.6f;
    }
}