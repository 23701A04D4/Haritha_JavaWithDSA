package SortingandSearching;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class backtracking {

	public static void main(String[] args) {
		int n=4;
		char[][] board=new char[n][n];
		for(char[]row:board){
			Arrays.fill(row, '.');// TODO Auto-generated method stub
		}
List<List<String>>solutions=new ArrayList<>();
SolveNQueens(0,board,solutions);
System.out.println("Total solutions:" +solutions.size());
for(List<String>sol:solutions) {
	for(String row:sol) {
		System.out.println(row);
	}
	System.out.println(n);
}
	}
	static void SolveNQueens(int row,char[][] board,List<List<String>>solutions) {
		int n=board.length;
		if(row==n) {
			solutions.add(construct(board));
			return;
			}
		for(int col=0;col<n;col++) {
			if(issafe(board,row,col)) {
				board[row][col]='Q';
				}
		}
}
	static boolean issafe(char[][]board,int row,int col) {
		int n=board.length;
		for(int i=0;i<row;i++)
			if(board[i][col]=='Q')return false;
		for(int i=row-1,j=col-1;i>=0&&j>=0;i--,j++)
			if(board[i][j]=='Q')return false;
		for(int i=row-1,j=col+1;i>0&&j<n;i--,j++)
			if(board[i][j]=='Q')return false;
		return true;}
		static List<String>construct(char[][]board){
			List<String>result=new ArrayList<>();
			for(char[]row:board) {
			result.add(new String(row));	
			}
			return result;
			
	}
	}


