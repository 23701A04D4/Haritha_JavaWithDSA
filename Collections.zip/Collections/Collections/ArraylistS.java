package Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ArraylistS {
	public static void main(String args[]) {
		/* ArrayList list = new ArrayList(); Creating arraylist */

		ArrayList<String> list = new ArrayList<String>(); 	// Generics
		list.add("Venkatesh");		// Adding in arraylist
		list.add("Stalin");
		list.add("Indramohan");
		list.add("Venkatesh");
						
		System.out.println(list); // Printing arraylist
		
		list.ensureCapacity(10);
		
 	/*  ListIterator<String> list2 = list.listIterator(); 
	  while(list2.hasNext()) 
	  {
		  System.out.println(list2.next()); 
	  }
	  System.out.println(list); // Printing arraylist
		
		ListIterator<String> list1 = list.listIterator(list.size());	// 3
		while (list1.hasPrevious()) 
		{
			System.out.println(list1.previous()); //i=3  i-- 
		}*/
		
		list.ensureCapacity(5000);
				//Collections.sort(list);			//Sorted List
		/*ArrayList<String> list1 = new ArrayList<String>();
		list1=(ArrayList)list.clone(); 
		System.out.println(list1); // Printing arraylist*/		
		
		
		//System.out.println(list.indexOf("Venkatesh"));
		//System.out.println(list.contains("Stalin"));
		 
		
		
		//System.out.println(list.size());
		/*for(String name:list) //for-each 
		{ System.out.println(name); }*/
		
		/*for(int i=0;i<list.size();i++) 		//3 <	3
		  { 
		  		System.out.println(list.get(i));	//getText or getValue 
		  }*/
		 
		for (Iterator<String> itr=list.iterator(); itr.hasNext(); )
        {
                System.out.println(itr.next());
        }
		
		/* Iterator<String> itr = list.iterator(); 	// getting Iterator while
		   while(itr.hasNext())				// check iterator has elements 
		   { 
			  // String output = itr.next();	// Assigning data and move next 
			  // System.out.println(output);  //i=0  i++    print(i)
		 		System.out.println(itr.next());  //i=0  i++    print(i)
		   }*/
		
		   // Iterates in reverse order


		
		/*  Collections.sort(list);			//Sorted List
		System.out.println(list);
			
		 System.out.println(list.get(1)); //return 2nd element
		 list.set(1,"Mohan Raj"); 		   //changing data
		 System.out.println(list.get(1)); 
		 list.remove(1);
		System.out.println(list);
		 list.add("Venkatesh");
		 System.out.println(list);*/
	}
}