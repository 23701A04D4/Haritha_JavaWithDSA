package Collections;

import java.util.ArrayList; 		//Class
import java.util.Collections;		//Class
import java.util.Iterator;
import java.util.List;  			//Interface

public class List1 {

	public static void main(String[] args) {
		//ArrayList<String> employeeList=new ArrayList<String>();
		
		List<String> employeeList = new ArrayList();	//Interface or Object
		employeeList.add("Venkatesh");
		employeeList.add("Mohanraj");
		employeeList.add("Venkatesh");
		/*System.out.println(employeeList);
		employeeList.set(1, "Indramohan");	
		System.out.println(employeeList);*/
		
		Iterator<String> itr1 = employeeList.iterator();
		while (itr1.hasNext()) //Any records
		{
			System.out.println(itr1.next());
			
		}
						
		Collections.sort(employeeList);			//Sorted List
		System.out.println( employeeList);

		Collections.reverse(employeeList);		//Reverse List
		System.out.println( employeeList);
		
		Collections.shuffle(employeeList);		//Shuffled List
		System.out.println( employeeList);
		
		System.out.println(Collections.frequency(employeeList,"Venkatesh"));
		//Checking occurance of Venkatesh
		
		employeeList.add("Venkatesh1");
		employeeList.contains("Venkatesh1");
		System.out.println( employeeList);
	}

}
