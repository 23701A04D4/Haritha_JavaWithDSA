package Collections;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class TreeAndHash {
	/*static int compare() {
		char s1[] = {'A', 'j', 'a', 'y'};
		char s2[] = {'R', 'a', 'v', 'i'};
		int a = s1.length;
		int b = s2.length;
		int limit = Math.min(a, b);
		int i = 0;
		while (i < limit)
		{
			char ch1 = s1[i];
			char ch2 = s2[i];
			if(ch1 != ch2)
			{	return ch1 - ch2;	}
		i++;
		}
	  return a - b; 
	}*/
	public static void main(String args[]) {
	//	System.out.println(TreeAndHash.compare());
		TreeSet<String> al = new TreeSet<String>();
		al.add("Ravi");
		al.add("Vijay");
		al.add("Ravi");
		al.add("Ajay");
		al.add("Bhoomi");
		//Comparator comp =al.comparator();
		//System.out.println(comp);
		
		Iterator<String> itr = al.iterator();
		while (itr.hasNext()) 
		{
			String output = itr.next();
			System.out.println(output);
			System.out.println(output.compareTo("Ravi"));
			System.out.println(output.equals("Ravi"));
		}
		System.out.println("");

		HashSet <String> set = new HashSet<String>(); 
		set.add("Ravi");
		set.add("Bhoomi");
		set.add("Vijay");
		set.add(null);
		set.add(null);
		set.add("Ajay");
		set.add("Ravi");

	/*	for (String m : set) 			//for-Each loop
		{
			System.out.println(m);
		}*/
		Iterator<String> itr1 = set.iterator();
		while (itr1.hasNext()) 
		{
			String output1 = itr1.next();
			System.out.println(output1);
		/*	System.out.println(output1.compareTo("Ravi"));
			System.out.println(output1.equals("Ravi"));*/
		}
	}
}
