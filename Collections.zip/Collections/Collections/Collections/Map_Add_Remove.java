package collections;

import java.util.HashMap;
import java.util.Map;

public class Map_Add_Remove {
	

	    public static void main(String[] args) {
	        // Creating a map using the HashMap
	        Map<String, Integer> numbers = new HashMap<>();

	        // Insert elements to the map
	        numbers.put("one", 1);
	        numbers.put("two", 0);
	        numbers.put("three",3);
	        numbers.put("four",0);
	        numbers.put("five", 0);
	        numbers.put("six",3);
	        
	     
	        
	        
	        
	        System.out.println("Map: " + numbers);
	        
	        
	        
//
//	        // Access keys of the map
//	        System.out.println("Keys: " + numbers.keySet());
//
//	        // Access values of the map
//	        System.out.println("Values: " + numbers.values());
//
        // Access entries of the map
	        System.out.println("Entries: " + numbers.entrySet());
//
//	        // Remove Elements from the map
//	        int value = numbers.remove("Two");
//	        System.out.println("Removed Value: " + value);
	    }
	}
