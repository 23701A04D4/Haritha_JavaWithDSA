package Collections;


import java.util.*;

public class index1 {
	public static void main(String [] args)
	{
	ArrayList<String> al = new ArrayList<String>();
	System.out.println("Initial size of al: " + al.size());
	al.add("C");
	al.add("A");
	al.add("E");
	al.add(1, "A2");
	
	index1 source = new index1();
	System.out.println("Element at index 3: " + source.printIndex(al, 3));
	//source.addAfter(al, "C", "c"));
	}

	private String printIndex(ArrayList<String> al, int i) {
			return al.get(i);

	}
}
