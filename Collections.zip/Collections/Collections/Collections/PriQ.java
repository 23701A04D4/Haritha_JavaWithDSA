package collections;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriQ {
public static void main(String[] args) {
	   PriorityQueue<String> namePriorityQueue = new PriorityQueue<>();

       // Add items to a Priority Queue
       namePriorityQueue.add("Lisa");
       namePriorityQueue.add("Robert");
       namePriorityQueue.add("John");
       namePriorityQueue.add("Chris");
       namePriorityQueue.add("Angelina");
       namePriorityQueue.add("Joe");

       
       // Remove items from the Priority Queue
       while (!namePriorityQueue.isEmpty()) {
           System.out.println(namePriorityQueue.remove());
       }
       System.out.println("               ");
       
       
       Queue<String>name=new LinkedList<>();
       name.add("Lisa");
       name.add("Robert");
       name.add("John");
       name.add("Chris");
       name.add("Angelina");
       name.add("Joe");
       
       while (!name.isEmpty()) {
           System.out.println(name.remove());
       }
       System.out.println("               ");
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
}
}
