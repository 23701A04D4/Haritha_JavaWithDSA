package collections;

import java.util.LinkedList;
import java.util.Queue;

public class Queues {

	public static void main(String[] args) {
		 Queue<String> name = new LinkedList<>();
    	 
	     // offer elements to the Queue
	         name.add("Siva");
	         name.add("Shan");
	         name.add("Nan");
	         
	         System.out.println("Queue: " + name);
	       
	         
	      // Access elements of the Queue
	        String topName=name.peek();
	        System.out.println("Top Name In Queue:"+topName);
	        
	        // Remove elements from the Queue
	        String removeName=name.poll();
	        
	        System.out.println("Removed Name :"+removeName);
	        
	        System.out.println(name);//After Removing the First Element Of the lsit
	        System.out.println(  name.remove());// Removing And Retrieving The values
	        System.out.println(name);
	}
	
	
}
