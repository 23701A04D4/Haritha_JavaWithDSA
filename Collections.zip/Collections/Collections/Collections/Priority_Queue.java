package collections;
import java.util.Collections;
import java.util.PriorityQueue;
	public class Priority_Queue {



		    public static void main(String[] args) {
		        // Creating Queue using the PriorityQueue class
		 PriorityQueue<Integer> numbers = new PriorityQueue<Integer>(Collections.reverseOrder());
		 PriorityQueue<Integer> numbers2 = new PriorityQueue<Integer>(Collections.reverseOrder());
			  	
		      // offer elements to the Queue
		System.out.println(numbers2.poll()); 
		// numbers2.remove();
		        numbers.add(1);
		        numbers.add(2);
		        numbers.add(3);
		        numbers.add(1);
		        numbers.add(2);
		        numbers.add(3);
		        numbers.add(1);
		        numbers.add(2);
		        numbers.add(3);
		        numbers.add(1);
		        numbers.add(2);
		        numbers.add(3
		        		);
		        
		        System.out.println("Queue: " + numbers);
		        
		    //  System.out.println(numbers.size());
		      
		        // Access elements of the Queue
//	        int accessedNumber = numbers.peek();
//		        System.out.println("Accessed Element: " + accessedNumber);
//
//		      
//		        // Remove elements from the Queue
//		        int removedNumber = numbers.poll();
//		        System.out.println("Removed Element: " + removedNumber);
//
//		        System.out.println("Updated Queue: " + numbers);
//		        // Creating Queue using the Linked List  class
//		    	 Queue<String> name = new LinkedList<>();
//		    	 
//		     // offer elements to the Queue
//		         name.add("Siva");
//		         name.add("Shan");
//		         name.add("nan");
//		         
//		         System.out.println("Queue: " + name);
//		       
//		         
//		      // Access elements of the Queue
//		        String topName=name.peek();
//		        System.out.println("Top Name In Queue:"+topName);
//		        
//		        // Remove elements from the Queue
//		        String removeName=name.poll();
//		        
//		        System.out.println("Removed Name :"+removeName);
//		        
//		        System.out.println(name);
//		        
//		        
		    }
		}

