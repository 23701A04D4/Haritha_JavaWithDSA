package Java;

class BankP {			//Main Class file <Features of Bank>
	float getRateOfInterest()   
	{
		return 0;              
	}
}
