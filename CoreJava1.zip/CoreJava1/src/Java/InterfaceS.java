package Java;

interface  InterfaceS {  
	void print();  
} 