package Java;

class Sam{  
 void method() throws Exception
 {  
	 //System.out.println("Inside called method");
	 int a = 50 / 0; 
	 System.out.println(a);
 }  
}  

class Exception4{  
   public static void main(String args[]) throws Exception{ 
	try{
		Sam obj = new Sam();  
		obj.method();  
	} 
	catch(Exception e)
	{System.out.println("Exception handled");}
	
    System.out.println("Inside main function");  
  }  
}  
